# WeatherWatch
A simple desktop weather application
