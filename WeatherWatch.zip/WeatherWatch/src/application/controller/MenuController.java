package application.controller;

import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.fxml.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import application.Main;
import application.model.WeatherWatch;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

/*
 * This class represents the MenuController
 */
public class MenuController {

	@FXML
	private BorderPane mainPane;
	@FXML
	private Pane view;
	@FXML
	ImageView background;

	/*
	 * Initialize the MenuContoller
	 * @throws Exception if initialization fails
	 */
	public void initialize(){
		try{
			URL fileUrl = Main.class.getResource("/application/view/Forecast.fxml");
			new FXMLLoader();
			view = FXMLLoader.load(fileUrl);
			mainPane.setCenter(view);
			}catch(Exception e){}
	}

	/*
	 * @throws Exception for handleButton1Action
	 */
	@FXML
	private void handleButton1Action(ActionEvent event){
		try{
			URL fileUrl = Main.class.getResource("/application/view/Forecast.fxml");
			new FXMLLoader();
			view = FXMLLoader.load(fileUrl);
			mainPane.setCenter(view);
			}catch(Exception e){e.printStackTrace();}

	}

	/*
	 * @throws Exception for handleButton2Action
	 */
	@FXML
	private void handleButton2Action(ActionEvent event){
		try{
			URL fileUrl = Main.class.getResource("/application/view/Radar.fxml");
			new FXMLLoader();
			view = FXMLLoader.load(fileUrl);
			mainPane.setCenter(view);
			}catch(Exception e){}
	}

	/*
	 * @throws Exception for handleButton3Action
	 */
	@FXML
	private void handleButton3Action(ActionEvent event){
		try{
			URL fileUrl = Main.class.getResource("/application/view/DetailedWeather.fxml");
			new FXMLLoader();
			view = FXMLLoader.load(fileUrl);
			mainPane.setCenter(view);
			}catch(Exception e){}
	}

	/*
	 * @throws Exception for handleButton4Action
	 */
	@FXML
	private void handleButton4Action(ActionEvent event){
		try{
			URL fileUrl = Main.class.getResource("/application/view/Location.fxml");
			new FXMLLoader();
			view = FXMLLoader.load(fileUrl);
			mainPane.setCenter(view);
			}catch(Exception e){}
	}

	/*
	 * Set the background
	 * @param fileName to set the background (String)
	 */
	public void setBackground(String fileName){
		 System.out.println("Is loaded: " );
		//	Image image = new Image(fileName);
		//	 System.out.println("Is loaded: " + image.isError());
		//	background.setImage(image);
	}
}
