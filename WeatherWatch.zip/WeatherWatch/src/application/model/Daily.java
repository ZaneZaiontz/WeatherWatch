package application.model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Gabrielle Albrecht/ypo253
 *
 */

/*
 * This class represents Daily weather
 */
public class Daily {

	private String high, low,  humidity, windSpeed, description, icon, pop;
	Long timestamp;

	//~~ Constructor
	/**
	 * Constructor that takes in seven strings and one long for daily weather
	 * @param high (String)
	 * @param low (String)
	 * @param humidity (String)
	 * @param windSpeed (String)
	 * @param pop (String)
	 * @param description (String)
	 * @param icon (String)
	 * @param timestamp (Long)
	 */
	public Daily(String high, String low, String humidity, String windSpeed,String pop, String description, String icon,Long timestamp){
		this.high = high;
		this.low = low;
		this.humidity = humidity;
		this.windSpeed = windSpeed;
		this.pop = pop;
		this.description = description;
		this.icon = icon;
		this.timestamp = timestamp;
	}

	//~~ Setters
	/**
	 * Set the High daily weather
	 * @param data (String)
	 */
	public void setHigh(String data){
		this.high = data;
	}

	/**
	 * Set the Low daily weather
	 * @param data (String)
	 */
	public void setLow(String data){
		this.low = data;
	}

	/**
	 * Set the WindSpeed for daily weather
	 * @param data (String)
	 */
	public void setWindSpeed(String data){
		this.windSpeed = data;
	}

	/**
	 * Set the Humidity for daily weather
	 * @param data (String)
	 */
	public void setHumidity(String data){
		this.humidity = data;
	}

	/**
	 * Set the Icon for daily weather
	 * @param data (String)
	 */
	public void setIcon(String data){
		this.icon = data;
	}

	/**
	 * Set the Description for daily weather
	 * @param data (String)
	 */
	public void setDescription(String data){
		this.description = data;
	}

	/**
	 * Set the Probability for Precipitation- Pop for daily weather
	 * @param data (String)
	 */
	public void setPop(String data){
		this.pop = data;
	}

	/**
	 * Set the Date for daily weather
	 * @param date (Long)
	 */
	public void setDate(Long date){
		this.timestamp = date;
	}

	//~~ Getters
	/**
	 * Get the High for daily weather
	 * @return high
	 */
	public String getHigh(){
		return this.high;
	}

	/**
	 * Get the HighInt for daily weather
	 * @return degree
	 */
	public int getHighInt(){
		Double result = Double.parseDouble(this.high);
		int degree = (int)Math.round(result);
		return degree;
	}

	/**
	 * Get the LowInt for daily weather
	 * @return degree
	 */
	public int getLowInt(){
		Double result = Double.parseDouble(this.low);
		int degree = (int)Math.round(result);
		return degree;
	}

	/**
	 * Get the Low for daily weather
	 * @return low
	 */
	public String getLow(){
		return this.low;
	}

	/**
	 * Get the WindSpeed for daily weather
	 * @return windSpeed
	 */
	public String getWindSpeed(){
		return this.windSpeed;
	}

	/**
	 * Get the Humidity for daily weather
	 * @return humidity
	 */
	public String getHumidity(){
		return this.humidity;
	}

	/**
	 * Get the Icon for daily weather
	 * @return icon
	 */
	public String getIcon(){
		return this.icon;
	}

	/**
	 * Get the Description for daily weather
	 * @return description
	 */
	public String getDescription(){
		return this.description;
	}

	/**
	 * Get the Date for daily weather
	 * @return timestamp
	 */
	public Long getDate(){
		return this.timestamp;
	}

	/**
	 * Get the Pop, Probability of Precipitation, for daily weather
	 * @return pop
	 */
	public String getPop(){
		return this.pop;
	}

	/**
	 * Get the PopPercent for daily weather
	 * @return percent
	 */
	public double getPopPercent(){
		Double result = Double.parseDouble(this.pop);
		double percent = (result*100);

		return percent;
	}

	/**
	 * Get the Day for daily weather
	 * @return java_date
	 */
	public String getDay(){
		 Date date = new Date(this.timestamp*1000L);
		 SimpleDateFormat jdf = new SimpleDateFormat("E dd");
		 String java_date = jdf.format(date);
		 return java_date;
	}

	//~~ toString()
	/**
	 * toString() prints the daily weather, returns a String
	 * @return data String to print the daily weather
	 */
	public String toString(){
		return (this.high + "/" + this.low + "Humidity: " + this.humidity + " " + this.windSpeed + " " + this.timestamp);
	}
}
