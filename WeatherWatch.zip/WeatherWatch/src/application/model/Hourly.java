package application.model;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Gabrielle Albrecht/ypo253
 *
 */

/*
 * This class represents the Hourly weather
 */
public class Hourly {
	private String temp,  humidity, windSpeed, description, icon;
	Long date;

	//~~ Constructor
	/**
	 * Constructor that takes in five Strings and one long
	 * @param temp (String)
	 * @param humidity (String)
	 * @param windSpeed (String)
	 * @param description (String)
	 * @param icon (String)
	 * @param date (Long)
	 */
	public Hourly(String temp, String humidity, String windSpeed, String description, String icon, Long date){
		this.temp = temp;
		this.humidity = humidity;
		this.windSpeed = windSpeed;
		this.description = description;
		this.icon = icon;
		this.date = date;
	}

	//~~ Setters
	/**
	 * Set the Temp for hourly weather
	 * @param data (String)
	 */
	public void setTemp(String data){
		this.temp = data;
	}

	/**
	 * Set the WindSpeed for hourly weather
	 * @param data (String)
	 */
	public void setWindSpeed(String data){
		this.windSpeed = data;
	}

	/**
	 * Set the Humidity for hourly weather
	 * @param data (String)
	 */
	public void setHumidity(String data){
		this.humidity = data;
	}

	/**
	 * Set the Icon for hourly weather
	 * @param data (String)
	 */
	public void setIcon(String data){
		this.icon = data;
	}

	/**
	 * Set the Description for hourly weather
	 * @param data (String)
	 */
	public void setDescription(String data){
		this.description = data;
	}

	/**
	 * Set the Date for hourly weather
	 * @param date (Long)
	 */
	public void setDate(Long date){
		this.date = date;
	}

	//~~ Getters
	/**
	 * Get the Temp for hourly weather
	 * @return temp
	 */
	public String getTemp(){
		return this.temp;
	}

	/**
	 * Get the WindSpeed for hourly weather
	 * @return windSpeed
	 */
	public String getWindSpeed(){
		return this.windSpeed;
	}

	/**
	 * Get the Humidity for hourly weather
	 * @return humidity
	 */
	public String getHumidity(){
		return this.humidity;
	}

	/**
	 * Get the Icon for hourly weather
	 * @return icon
	 */
	public String getIcon(){
		return this.icon;
	}

	/**
	 * Get the Description for hourly weather
	 * @return description
	 */
	public String getDescription(){
		return this.description;
	}

	/**
	 * Get the Date for hourly weather
	 * @return date
	 */
	public Long getDate(){
		return this.date;
	}

	/**
	 * Get the Day for hourly weather
	 * @return newDate
	 */
	public String getDay(){
		 Date date = new Date(this.date*1000L);
		 SimpleDateFormat jdf = new SimpleDateFormat("EEE MM dd hh:mm:ss z");
		 String newDate = jdf.format(date);

		 return newDate;
	}

	//~~ toString()
	/**
	 * toString() prints the hourly weather, returns a String
	 * @return data String to print the hourly weather
	 */

	public String toString(){
		return (getDay() + ": " + this.temp + "°F, " + this.humidity + "% humidity, " + this.windSpeed + " mph wind");
	}
}
